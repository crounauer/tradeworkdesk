import { useState, useEffect } from "react";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  CheckCircle,
  Star,
  ChevronDown,
  ChevronRight,
  Menu,
  X,
  Wrench,
  Droplets,
  ShowerHead,
  Thermometer,
  AlertTriangle,
  Calendar,
  ArrowRight,
  Shield,
  Award,
  ThumbsUp,
  Zap,
  Camera,
  FileText,
  Home,
  ChevronLeft,
  ExternalLink,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type Page =
  | "home"
  | "services"
  | "service-detail"
  | "emergency"
  | "areas"
  | "reviews"
  | "gallery"
  | "blog-index"
  | "blog-post"
  | "booking"
  | "contact"
  | "legal"
  | "404";

// ─── Constants ───────────────────────────────────────────────────────────────

const PHONE = "01234 567 890";
const PHONE_HREF = "tel:01234567890";
const COMPANY = "Local Plumbing Pro";
const TAGLINE = "Reliable, Honest Plumbers in Your Area";

const NAV_LINKS: { label: string; page: Page }[] = [
  { label: "Home", page: "home" },
  { label: "Services", page: "services" },
  { label: "Emergency", page: "emergency" },
  { label: "Areas", page: "areas" },
  { label: "Reviews", page: "reviews" },
  { label: "Gallery", page: "gallery" },
  { label: "Blog", page: "blog-index" },
  { label: "Book Online", page: "booking" },
  { label: "Contact", page: "contact" },
];

const SERVICES_DATA = [
  { icon: <Droplets size={28} />, title: "Leak Detection & Repair", desc: "Burst pipes, concealed leaks, dripping joints — we trace and fix leaks fast to prevent costly water damage.", slug: "leak-repair" },
  { icon: <Wrench size={28} />, title: "Taps & Mixers", desc: "Dripping taps, stiff handles, worn cartridges. Supply and fit of all leading UK tap brands.", slug: "taps" },
  { icon: <Home size={28} />, title: "Toilets & WCs", desc: "Cistern repairs, slow-fill valves, leaking bases, full toilet replacements — we handle it all.", slug: "toilets" },
  { icon: <ShowerHead size={28} />, title: "Showers & Enclosures", desc: "Electric shower fitting, thermostatic valves, shower tray leaks, and pump installations.", slug: "showers" },
  { icon: <Zap size={28} />, title: "Pipework & Repairs", desc: "Copper re-piping, plastic push-fit alterations, pressure testing and pipe lagging.", slug: "pipework" },
  { icon: <Thermometer size={28} />, title: "Radiators", desc: "Bleeding, balancing, thermostatic valve replacement, and full radiator swaps.", slug: "radiators" },
  { icon: <Droplets size={28} />, title: "Outdoor Taps", desc: "New outdoor tap installation with double-check valve — perfect for gardens and car washing.", slug: "outdoor-taps" },
  { icon: <Shield size={28} />, title: "Plumbing Maintenance", desc: "Annual plumbing checks, water pressure testing, and proactive maintenance to avoid breakdowns.", slug: "maintenance" },
  { icon: <AlertTriangle size={28} />, title: "Emergency Plumbing", desc: "24/7 rapid response to burst pipes, flooding, and major leaks. We aim to be with you within 2 hours.", slug: "emergency" },
  { icon: <Wrench size={28} />, title: "Small Plumbing Jobs", desc: "No job too small — washer replacements, isolation valves, flexi hoses, and minor repairs.", slug: "small-jobs" },
];

const TESTIMONIALS_DATA = [
  { name: "Sarah T.", location: "Reading", stars: 5, text: "Brilliant service — came out within an hour to fix a burst pipe under our kitchen sink. Professional, tidy and very reasonable price. Will definitely use again.", date: "March 2025" },
  { name: "James M.", location: "Caversham", stars: 5, text: "Had a dripping tap driving me mad for weeks. Called Local Plumbing Pro and they were here same afternoon. Fixed in 20 minutes. Couldn't be happier.", date: "February 2025" },
  { name: "Linda P.", location: "Woodley", stars: 5, text: "Replaced our old shower with a new thermostatic one. Spotless job, no mess left behind and they even tidied up the pipework. Highly recommend!", date: "January 2025" },
  { name: "Raj S.", location: "Earley", stars: 5, text: "Emergency call at 11pm for a leaking toilet. They answered straight away and arrived within 90 minutes. Genuinely impressive response time.", date: "December 2024" },
  { name: "Carol W.", location: "Tilehurst", stars: 5, text: "Used them for a full bathroom plumbing rough-in. Quality workmanship, kept us updated throughout and finished on schedule. Very professional team.", date: "November 2024" },
  { name: "Dave H.", location: "Pangbourne", stars: 4, text: "Great job fitting outdoor tap and new kitchen mixer. Honest with the quote — no hidden extras. Would definitely book again.", date: "October 2024" },
];

const AREAS_DATA = [
  "Reading", "Caversham", "Woodley", "Earley", "Tilehurst", "Pangbourne",
  "Henley-on-Thames", "Twyford", "Wokingham", "Bracknell", "Maidenhead", "Newbury",
  "Thatcham", "Tadley", "Basingstoke", "Hook", "Fleet", "Farnham",
];

const FAQ_DATA = [
  { q: "Do you charge a call-out fee?", a: "We offer free no-obligation quotes for all non-emergency work. For emergency call-outs outside of standard hours, a call-out fee applies — we'll always confirm this before arriving." },
  { q: "Are you insured and registered?", a: "Yes, we hold full public liability insurance (£5 million cover) and are registered with the relevant trade bodies. All our work is guaranteed for 12 months." },
  { q: "How quickly can you respond to an emergency?", a: "We aim to reach emergency call-outs within 2 hours, 24 hours a day, 7 days a week. Our local base means we're rarely far away." },
  { q: "Do you provide a written quote?", a: "Absolutely. For all planned work we provide a clear written quote before starting. No hidden costs or surprise extras." },
  { q: "Can you source parts and materials?", a: "Yes — we carry a wide range of commonly needed parts in our van. For specialist fittings we'll source them quickly from trusted local suppliers." },
  { q: "What areas do you cover?", a: "We cover Reading and the surrounding towns within approximately 20 miles, including Woodley, Earley, Caversham, Wokingham, Bracknell, Maidenhead, and more." },
];

const PROCESS_STEPS = [
  { step: "1", title: "Call or Book Online", desc: "Ring us for a free quote or use our online booking form — we'll confirm availability within the hour." },
  { step: "2", title: "We Diagnose the Problem", desc: "Our engineer arrives on time, assesses the issue and explains the fix in plain English before touching anything." },
  { step: "3", title: "Work Completed Neatly", desc: "We carry out the work to a high standard, protecting your home and clearing up completely when finished." },
  { step: "4", title: "Your 12-Month Guarantee", desc: "All workmanship is backed by our 12-month guarantee. If anything isn't right, we'll fix it free of charge." },
];

const BLOG_POSTS = [
  { slug: "stop-dripping-tap", title: "How to Stop a Dripping Tap (And When to Call a Plumber)", excerpt: "A dripping tap can waste over 5,000 litres of water a year. Here's what causes it and what you can do.", date: "15 June 2025", readTime: "4 min read", category: "Tips & Advice" },
  { slug: "frozen-pipes-prevention", title: "Preventing Frozen Pipes This Winter: A UK Homeowner's Guide", excerpt: "Cold snaps can wreak havoc on your plumbing. Our guide covers insulation, stopcocks and what to do if the worst happens.", date: "3 November 2024", readTime: "6 min read", category: "Winter Advice" },
  { slug: "water-pressure-low", title: "Low Water Pressure? Here's Why and How to Fix It", excerpt: "Poor pressure makes showers miserable. We walk through the most common causes and the solutions available to UK homeowners.", date: "18 August 2024", readTime: "5 min read", category: "Troubleshooting" },
  { slug: "outdoor-tap-benefits", title: "5 Reasons to Install an Outdoor Tap Before Summer", excerpt: "Garden watering, car washing, filling paddling pools — a properly fitted outdoor tap makes life much easier.", date: "12 April 2024", readTime: "3 min read", category: "Home Improvement" },
];

const GALLERY_IMAGES = [
  { url: "https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=600&h=450&fit=crop&auto=format", alt: "New bathroom mixer tap installation" },
  { url: "https://images.unsplash.com/photo-1504148455328-c376907d081c?w=600&h=450&fit=crop&auto=format", alt: "Modern shower enclosure fitting" },
  { url: "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=600&h=450&fit=crop&auto=format", alt: "Copper pipework installation" },
  { url: "https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=600&h=450&fit=crop&auto=format", alt: "Bathroom radiator replacement" },
  { url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=450&fit=crop&auto=format", alt: "Outdoor tap installation in garden" },
  { url: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=450&fit=crop&auto=format", alt: "Kitchen under-sink plumbing repair" },
];

// ─── Shared UI Components ─────────────────────────────────────────────────────

function CallBtn({ className = "" }: { className?: string }) {
  return (
    <a
      href={PHONE_HREF}
      className={`inline-flex items-center gap-2 bg-accent text-accent-foreground font-bold px-5 py-3 rounded-lg hover:brightness-110 transition-all active:scale-95 ${className}`}
    >
      <Phone size={18} /> {PHONE}
    </a>
  );
}

function PrimaryBtn({ children, onClick, className = "" }: { children: React.ReactNode; onClick?: () => void; className?: string }) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-2 bg-primary text-primary-foreground font-semibold px-5 py-3 rounded-lg hover:bg-primary/90 transition-all active:scale-95 ${className}`}
    >
      {children}
    </button>
  );
}

function AccentBtn({ children, onClick, className = "" }: { children: React.ReactNode; onClick?: () => void; className?: string }) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-2 bg-accent text-accent-foreground font-semibold px-5 py-3 rounded-lg hover:brightness-110 transition-all active:scale-95 ${className}`}
    >
      {children}
    </button>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-block text-accent font-semibold text-sm tracking-widest uppercase mb-3">
      {children}
    </span>
  );
}

function Stars({ count = 5 }: { count?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <Star key={i} size={16} className="text-yellow-400 fill-yellow-400" />
      ))}
    </div>
  );
}

// ─── BLOCK: site.header (Nav) ─────────────────────────────────────────────────

function SiteHeader({ currentPage, navigate }: { currentPage: Page; navigate: (p: Page) => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all ${scrolled ? "bg-primary shadow-lg" : "bg-primary"}`}>
        {/* Top bar */}
        <div className="bg-primary/95 border-b border-white/10 hidden md:block">
          <div className="max-w-7xl mx-auto px-4 flex justify-between items-center py-1.5 text-sm text-white/80">
            <div className="flex items-center gap-6">
              <span className="flex items-center gap-1.5"><Clock size={13} /> Mon–Sat 7am–8pm | Emergency 24/7</span>
              <span className="flex items-center gap-1.5"><MapPin size={13} /> Reading & Surrounding Areas</span>
            </div>
            <a href={PHONE_HREF} className="flex items-center gap-1.5 text-accent font-bold hover:text-white transition-colors">
              <Phone size={13} /> {PHONE}
            </a>
          </div>
        </div>
        {/* Main nav */}
        <nav className="max-w-7xl mx-auto px-4 flex items-center justify-between h-16">
          <button
            onClick={() => navigate("home")}
            className="flex items-center gap-2 text-white font-bold text-lg"
            style={{ fontFamily: "var(--font-display)" }}
          >
            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
              <Droplets size={18} className="text-white" />
            </div>
            <span className="hidden sm:block">{COMPANY}</span>
          </button>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((l) => (
              <button
                key={l.page}
                onClick={() => navigate(l.page)}
                className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${currentPage === l.page ? "bg-white/20 text-white" : "text-white/80 hover:text-white hover:bg-white/10"}`}
              >
                {l.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <a href={PHONE_HREF} className="hidden sm:flex items-center gap-2 bg-accent text-white font-bold text-sm px-4 py-2 rounded-lg hover:brightness-110 transition-all">
              <Phone size={15} /> Call Now
            </a>
            <button className="lg:hidden text-white p-1" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </nav>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="lg:hidden bg-primary border-t border-white/10 py-4 px-4 flex flex-col gap-1">
            {NAV_LINKS.map((l) => (
              <button
                key={l.page}
                onClick={() => { navigate(l.page); setMenuOpen(false); }}
                className={`text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${currentPage === l.page ? "bg-white/20 text-white" : "text-white/70 hover:text-white hover:bg-white/10"}`}
              >
                {l.label}
              </button>
            ))}
            <div className="pt-2 mt-2 border-t border-white/10">
              <a href={PHONE_HREF} className="flex items-center justify-center gap-2 bg-accent text-white font-bold py-3 rounded-lg">
                <Phone size={18} /> {PHONE}
              </a>
            </div>
          </div>
        )}
      </header>
      {/* Spacer for fixed header */}
    </>
  );
}

// ─── BLOCK: site.footer ───────────────────────────────────────────────────────

function SiteFooter({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <footer className="bg-primary text-white">
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand */}
        <div className="md:col-span-1">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
              <Droplets size={18} className="text-white" />
            </div>
            <span className="font-bold text-lg" style={{ fontFamily: "var(--font-display)" }}>{COMPANY}</span>
          </div>
          <p className="text-white/70 text-sm leading-relaxed mb-4">Honest, reliable local plumbers serving Reading and surrounding areas. Fully insured. 12-month workmanship guarantee.</p>
          <a href={PHONE_HREF} className="flex items-center gap-2 text-accent font-bold hover:text-white transition-colors">
            <Phone size={16} /> {PHONE}
          </a>
        </div>
        {/* Services */}
        <div>
          <h4 className="font-semibold mb-4 text-white/90">Services</h4>
          <ul className="space-y-2 text-sm text-white/60">
            {["Leak Repair", "Taps & Mixers", "Toilets", "Showers", "Pipework", "Radiators", "Emergency Plumbing"].map((s) => (
              <li key={s}>
                <button onClick={() => navigate("services")} className="hover:text-accent transition-colors">{s}</button>
              </li>
            ))}
          </ul>
        </div>
        {/* Pages */}
        <div>
          <h4 className="font-semibold mb-4 text-white/90">Quick Links</h4>
          <ul className="space-y-2 text-sm text-white/60">
            {[
              { label: "About Us", page: "home" as Page },
              { label: "Areas Covered", page: "areas" as Page },
              { label: "Customer Reviews", page: "reviews" as Page },
              { label: "Photo Gallery", page: "gallery" as Page },
              { label: "Blog", page: "blog-index" as Page },
              { label: "Book Online", page: "booking" as Page },
              { label: "Contact Us", page: "contact" as Page },
              { label: "Privacy Policy", page: "legal" as Page },
            ].map((l) => (
              <li key={l.label}>
                <button onClick={() => navigate(l.page)} className="hover:text-accent transition-colors">{l.label}</button>
              </li>
            ))}
          </ul>
        </div>
        {/* Contact */}
        <div>
          <h4 className="font-semibold mb-4 text-white/90">Contact</h4>
          <ul className="space-y-3 text-sm text-white/70">
            <li className="flex items-start gap-2"><Phone size={15} className="mt-0.5 text-accent shrink-0" /> <span>{PHONE}</span></li>
            <li className="flex items-start gap-2"><Mail size={15} className="mt-0.5 text-accent shrink-0" /> <span>hello@localplumbingpro.co.uk</span></li>
            <li className="flex items-start gap-2"><MapPin size={15} className="mt-0.5 text-accent shrink-0" /> <span>Reading, Berkshire &amp; surrounding areas within 20 miles</span></li>
            <li className="flex items-start gap-2"><Clock size={15} className="mt-0.5 text-accent shrink-0" /> <span>Mon–Sat 7am–8pm<br />Emergency cover 24/7</span></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-white/40">
          <span>© 2025 {COMPANY}. All rights reserved.</span>
          <div className="flex gap-4">
            <button onClick={() => navigate("legal")} className="hover:text-white transition-colors">Privacy Policy</button>
            <button onClick={() => navigate("legal")} className="hover:text-white transition-colors">Terms & Conditions</button>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── BLOCK: sticky_mobile_cta ─────────────────────────────────────────────────

function StickyMobileCta({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-white border-t border-border shadow-lg">
      <div className="grid grid-cols-2 divide-x divide-border">
        <a href={PHONE_HREF} className="flex flex-col items-center justify-center py-3 gap-0.5 text-accent font-bold text-xs">
          <Phone size={20} />
          <span>Call Now</span>
        </a>
        <button onClick={() => navigate("booking")} className="flex flex-col items-center justify-center py-3 gap-0.5 text-primary font-bold text-xs">
          <Calendar size={20} />
          <span>Book Online</span>
        </button>
      </div>
    </div>
  );
}

// ─── BLOCK: hero ─────────────────────────────────────────────────────────────

function HeroBlock({
  title,
  subtitle,
  bgImage,
  dark = true,
  navigate,
  showTrust = false,
  emergencyMode = false,
}: {
  title: string;
  subtitle?: string;
  bgImage?: string;
  dark?: boolean;
  navigate: (p: Page) => void;
  showTrust?: boolean;
  emergencyMode?: boolean;
}) {
  return (
    <section
      className="relative pt-32 md:pt-[200px] pb-16 md:pb-24 px-4"
      style={{
        background: bgImage
          ? `linear-gradient(rgba(15,31,61,0.75), rgba(15,31,61,0.85)), url(${bgImage}) center/cover no-repeat`
          : emergencyMode
          ? "linear-gradient(135deg, #b91c1c 0%, #1a3a6b 100%)"
          : "linear-gradient(135deg, #1a3a6b 0%, #0f1f3d 100%)",
      }}
    >
      <div className="max-w-4xl mx-auto text-center">
        {emergencyMode && (
          <div className="inline-flex items-center gap-2 bg-red-500 text-white text-sm font-bold px-4 py-1.5 rounded-full mb-6 animate-pulse">
            <AlertTriangle size={16} /> 24/7 Emergency Service Available
          </div>
        )}
        <h1
          className="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4"
          style={{ fontFamily: "var(--font-display)" }}
        >
          {title}
        </h1>
        {subtitle && <p className="text-white/80 text-lg md:text-xl max-w-2xl mx-auto mb-8">{subtitle}</p>}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <a href={PHONE_HREF} className="inline-flex items-center justify-center gap-2 bg-accent text-white font-bold px-6 py-3.5 rounded-lg hover:brightness-110 transition-all text-lg">
            <Phone size={20} /> Call Now: {PHONE}
          </a>
          <button
            onClick={() => navigate("booking")}
            className="inline-flex items-center justify-center gap-2 bg-white text-primary font-bold px-6 py-3.5 rounded-lg hover:bg-white/90 transition-all text-lg"
          >
            <Calendar size={20} /> Request a Quote
          </button>
        </div>
        {showTrust && (
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            {[
              { icon: <Shield size={16} />, text: "Fully Insured" },
              { icon: <MapPin size={16} />, text: "Local Engineers" },
              { icon: <Zap size={16} />, text: "Fast Response" },
              { icon: <CheckCircle size={16} />, text: "Free Quotes" },
            ].map((t) => (
              <div key={t.text} className="flex items-center gap-1.5 bg-white/15 text-white text-sm px-3 py-1.5 rounded-full font-medium">
                {t.icon} {t.text}
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

// ─── BLOCK: features_bar ─────────────────────────────────────────────────────

function FeaturesBarBlock() {
  const items = [
    { icon: <Shield size={22} />, text: "Fully Insured" },
    { icon: <MapPin size={22} />, text: "Local Engineers" },
    { icon: <Zap size={22} />, text: "2-Hour Emergency" },
    { icon: <CheckCircle size={22} />, text: "Free Quotes" },
    { icon: <Award size={22} />, text: "12-Month Guarantee" },
    { icon: <Clock size={22} />, text: "Mon–Sat 7am–8pm" },
  ];
  return (
    <section className="bg-secondary border-b border-border">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex flex-wrap justify-center md:justify-between gap-y-3 gap-x-4">
          {items.map((i) => (
            <div key={i.text} className="flex items-center gap-2 text-primary text-sm font-semibold">
              <span className="text-accent">{i.icon}</span>
              {i.text}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: services ─────────────────────────────────────────────────────────

function ServicesBlock({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <SectionLabel>What We Do</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>
            Plumbing Services We Cover
          </h2>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto">From emergency call-outs to planned upgrades — expert plumbing for homes and businesses across the area.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES_DATA.map((s) => (
            <button
              key={s.slug}
              onClick={() => navigate("service-detail")}
              className="group text-left bg-card border border-border rounded-xl p-6 hover:border-accent hover:shadow-lg transition-all"
            >
              <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center text-accent mb-4 group-hover:bg-accent group-hover:text-white transition-colors">
                {s.icon}
              </div>
              <h3 className="font-bold text-foreground text-lg mb-2">{s.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-3">{s.desc}</p>
              <span className="text-accent text-sm font-semibold flex items-center gap-1 group-hover:gap-2 transition-all">
                Learn more <ChevronRight size={14} />
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: why_choose_us ─────────────────────────────────────────────────────

function WhyChooseUsBlock() {
  const reasons = [
    { icon: <Shield size={24} />, title: "Fully Insured & Guaranteed", desc: "£5 million public liability cover and a 12-month guarantee on all our work. You're in safe hands." },
    { icon: <ThumbsUp size={24} />, title: "Honest, Upfront Pricing", desc: "We quote before we start and stick to it. No nasty surprises on your invoice — ever." },
    { icon: <Zap size={24} />, title: "Rapid Response Times", desc: "Most standard jobs booked within 48 hours. Emergencies attended within 2 hours around the clock." },
    { icon: <Award size={24} />, title: "Qualified Tradespeople", desc: "All our engineers are time-served, trained professionals — not labourers learning on the job." },
    { icon: <MapPin size={24} />, title: "Genuinely Local", desc: "We're based in your area, not a national franchise. You'll speak to the same people every time." },
    { icon: <Camera size={24} />, title: "Tidy, Respectful Workers", desc: "We treat your home as our own — dust sheets, shoe covers, and a full tidy-up before we leave." },
  ];
  return (
    <section className="py-16 px-4 bg-secondary">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <SectionLabel>Why Us</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>
            Why Choose Local Plumbing Pro?
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((r) => (
            <div key={r.title} className="bg-card rounded-xl p-6 border border-border">
              <div className="w-11 h-11 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-4">{r.icon}</div>
              <h3 className="font-bold text-foreground mb-2">{r.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: process ───────────────────────────────────────────────────────────

function ProcessBlock() {
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <SectionLabel>How It Works</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>
            Our Simple 4-Step Process
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {PROCESS_STEPS.map((step, idx) => (
            <div key={step.step} className="relative text-center">
              {idx < PROCESS_STEPS.length - 1 && (
                <div className="hidden md:block absolute top-8 left-1/2 w-full h-0.5 bg-accent/30 z-0" />
              )}
              <div className="relative z-10 w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white font-extrabold text-xl mx-auto mb-4 shadow-md" style={{ fontFamily: "var(--font-display)" }}>
                {step.step}
              </div>
              <h3 className="font-bold text-foreground mb-2">{step.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: areas ─────────────────────────────────────────────────────────────

function AreasBlock({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <section className="py-16 px-4 bg-secondary">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <SectionLabel>Coverage</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>
            Areas We Cover
          </h2>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto">Based in Reading, we serve homeowners and businesses across the town and surrounding Berkshire villages and towns.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
          {AREAS_DATA.map((a) => (
            <button
              key={a}
              onClick={() => navigate("areas")}
              className="bg-card border border-border rounded-lg px-3 py-2.5 text-sm font-medium text-foreground hover:border-accent hover:text-accent transition-colors text-center"
            >
              {a}
            </button>
          ))}
        </div>
        <div className="text-center">
          <p className="text-muted-foreground text-sm mb-3">Not sure if we cover your area?</p>
          <a href={PHONE_HREF} className="inline-flex items-center gap-2 text-accent font-semibold hover:underline">
            <Phone size={16} /> Give us a call to check — {PHONE}
          </a>
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: testimonials ──────────────────────────────────────────────────────

function TestimonialsBlock() {
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <SectionLabel>Customer Reviews</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>
            What Our Customers Say
          </h2>
          <div className="flex items-center justify-center gap-2 mt-3">
            <Stars />
            <span className="text-muted-foreground text-sm font-medium">4.9 / 5 from 120+ reviews</span>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {TESTIMONIALS_DATA.map((t) => (
            <div key={t.name} className="bg-card border border-border rounded-xl p-6">
              <Stars count={t.stars} />
              <p className="mt-3 text-foreground text-sm leading-relaxed italic">&ldquo;{t.text}&rdquo;</p>
              <div className="mt-4 pt-4 border-t border-border flex justify-between items-center">
                <div>
                  <p className="font-semibold text-foreground text-sm">{t.name}</p>
                  <p className="text-muted-foreground text-xs">{t.location}</p>
                </div>
                <span className="text-muted-foreground text-xs">{t.date}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: project_showcase ──────────────────────────────────────────────────

function ProjectShowcaseBlock({ navigate }: { navigate: (p: Page) => void }) {
  const projects = [
    { img: GALLERY_IMAGES[0], title: "Complete Bathroom Replumb", location: "Reading", tags: ["Pipework", "Taps"] },
    { img: GALLERY_IMAGES[1], title: "Thermostatic Shower Fit", location: "Caversham", tags: ["Showers"] },
    { img: GALLERY_IMAGES[2], title: "Kitchen Re-pipe & Relocation", location: "Woodley", tags: ["Pipework", "Taps"] },
  ];
  return (
    <section className="py-16 px-4 bg-secondary">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <SectionLabel>Our Work</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>
            Recent Projects
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {projects.map((p) => (
            <button key={p.title} onClick={() => navigate("gallery")} className="group text-left bg-card rounded-xl overflow-hidden border border-border hover:shadow-lg transition-all">
              <div className="h-48 bg-muted overflow-hidden">
                <img src={p.img.url} alt={p.img.alt} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-5">
                <div className="flex gap-2 mb-2">
                  {p.tags.map((t) => <span key={t} className="text-xs bg-accent/10 text-accent font-semibold px-2 py-0.5 rounded-full">{t}</span>)}
                </div>
                <h3 className="font-bold text-foreground">{p.title}</h3>
                <p className="text-muted-foreground text-sm flex items-center gap-1 mt-1"><MapPin size={13} /> {p.location}</p>
              </div>
            </button>
          ))}
        </div>
        <div className="text-center mt-8">
          <button onClick={() => navigate("gallery")} className="inline-flex items-center gap-2 text-accent font-semibold hover:underline">
            View full gallery <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: faq ───────────────────────────────────────────────────────────────

function FaqBlock({ items = FAQ_DATA }: { items?: typeof FAQ_DATA }) {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <SectionLabel>FAQs</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>
            Frequently Asked Questions
          </h2>
        </div>
        <div className="space-y-3">
          {items.map((item, idx) => (
            <div key={idx} className="bg-card border border-border rounded-xl overflow-hidden">
              <button
                className="w-full text-left px-5 py-4 flex items-center justify-between gap-3 font-semibold text-foreground hover:text-accent transition-colors"
                onClick={() => setOpen(open === idx ? null : idx)}
              >
                <span>{item.q}</span>
                <ChevronDown size={18} className={`shrink-0 text-muted-foreground transition-transform ${open === idx ? "rotate-180" : ""}`} />
              </button>
              {open === idx && (
                <div className="px-5 pb-4 text-muted-foreground text-sm leading-relaxed border-t border-border pt-4">
                  {item.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: cta ───────────────────────────────────────────────────────────────

function CtaBlock({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <section className="py-16 px-4 bg-primary">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-4" style={{ fontFamily: "var(--font-display)" }}>
          Ready to Book or Need Advice?
        </h2>
        <p className="text-white/80 mb-8 text-lg">Call us for a free quote, or fill in our quick online form and we'll get back to you within the hour.</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href={PHONE_HREF} className="inline-flex items-center justify-center gap-2 bg-accent text-white font-bold px-6 py-3.5 rounded-lg hover:brightness-110 transition-all text-lg">
            <Phone size={20} /> {PHONE}
          </a>
          <button onClick={() => navigate("booking")} className="inline-flex items-center justify-center gap-2 bg-white text-primary font-bold px-6 py-3.5 rounded-lg hover:bg-white/90 transition-all text-lg">
            <Calendar size={20} /> Request a Quote
          </button>
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: contact_form ──────────────────────────────────────────────────────

function ContactFormBlock() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", email: "", service: "", message: "" });
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };
  if (sent) {
    return (
      <section className="py-16 px-4 bg-secondary">
        <div className="max-w-2xl mx-auto text-center">
          <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} className="text-accent" />
          </div>
          <h3 className="text-2xl font-bold text-foreground mb-2">Enquiry Received!</h3>
          <p className="text-muted-foreground">Thanks for getting in touch. We'll call or email you back within 1 hour during working hours.</p>
        </div>
      </section>
    );
  }
  return (
    <section className="py-16 px-4 bg-secondary">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-10">
          <SectionLabel>Get in Touch</SectionLabel>
          <h2 className="text-3xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>Request a Free Quote</h2>
          <p className="mt-2 text-muted-foreground text-sm">We aim to respond to all enquiries within 1 hour during working hours.</p>
        </div>
        <form onSubmit={handleSubmit} className="bg-card border border-border rounded-2xl p-6 md:p-8 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-foreground mb-1.5">Full Name *</label>
              <input required type="text" placeholder="John Smith" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-input-background border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-foreground mb-1.5">Phone Number *</label>
              <input required type="tel" placeholder="07700 900 000" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full bg-input-background border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-foreground mb-1.5">Email Address</label>
            <input type="email" placeholder="john@example.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full bg-input-background border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-foreground mb-1.5">Service Required</label>
            <select value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })}
              className="w-full bg-input-background border border-border rounded-lg px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-accent/50">
              <option value="">Select a service…</option>
              {SERVICES_DATA.map((s) => <option key={s.slug}>{s.title}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-foreground mb-1.5">Describe the Problem *</label>
            <textarea required rows={4} placeholder="Please describe the issue you're experiencing and your approximate location…"
              value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="w-full bg-input-background border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50 resize-none" />
          </div>
          <button type="submit" className="w-full bg-primary text-primary-foreground font-bold py-3.5 rounded-lg hover:bg-primary/90 transition-colors text-base">
            Send Enquiry — We'll Call You Back
          </button>
          <p className="text-center text-xs text-muted-foreground">For emergencies, please call us directly on <a href={PHONE_HREF} className="text-accent font-semibold">{PHONE}</a></p>
        </form>
      </div>
    </section>
  );
}

// ─── BLOCK: contact ───────────────────────────────────────────────────────────

function ContactBlock() {
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <SectionLabel>Contact Details</SectionLabel>
          <h2 className="text-3xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>Get in Touch</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: <Phone size={28} />, title: "Call Us", body: <><a href={PHONE_HREF} className="text-accent font-bold text-lg block hover:underline">{PHONE}</a><p className="text-sm text-muted-foreground mt-1">Mon–Sat 7am–8pm<br />Emergency 24/7</p></> },
            { icon: <Mail size={28} />, title: "Email Us", body: <><a href="mailto:hello@localplumbingpro.co.uk" className="text-accent font-semibold text-sm hover:underline">hello@localplumbingpro.co.uk</a><p className="text-sm text-muted-foreground mt-1">We aim to reply within 2 hours during working hours.</p></> },
            { icon: <MapPin size={28} />, title: "Area Covered", body: <><p className="text-foreground font-medium text-sm">Reading, Berkshire</p><p className="text-sm text-muted-foreground mt-1">We cover all areas within approximately 20 miles of Reading town centre.</p></> },
          ].map((c) => (
            <div key={c.title} className="bg-card border border-border rounded-xl p-6 flex flex-col items-start gap-3">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary">{c.icon}</div>
              <h3 className="font-bold text-foreground">{c.title}</h3>
              <div>{c.body}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: text ─────────────────────────────────────────────────────────────

function TextBlock({ title, children, bg = "bg-background" }: { title?: string; children: React.ReactNode; bg?: string }) {
  return (
    <section className={`py-12 px-4 ${bg}`}>
      <div className="max-w-3xl mx-auto prose prose-slate">
        {title && <h2 className="text-2xl font-extrabold text-foreground mb-4" style={{ fontFamily: "var(--font-display)" }}>{title}</h2>}
        <div className="text-muted-foreground leading-relaxed space-y-4">{children}</div>
      </div>
    </section>
  );
}

// ─── BLOCK: image ─────────────────────────────────────────────────────────────

function ImageBlock({ src, alt, caption }: { src: string; alt: string; caption?: string }) {
  return (
    <section className="py-8 px-4 bg-secondary">
      <div className="max-w-4xl mx-auto">
        <div className="rounded-2xl overflow-hidden bg-muted">
          <img src={src} alt={alt} className="w-full h-72 md:h-[420px] object-cover" />
        </div>
        {caption && <p className="text-center text-xs text-muted-foreground mt-3">{caption}</p>}
      </div>
    </section>
  );
}

// ─── BLOCK: feature_cards ─────────────────────────────────────────────────────

function FeatureCardsBlock() {
  const cards = [
    { icon: <Shield size={22} />, title: "Fully Insured Work", desc: "Every job we do is covered by £5m public liability insurance and backed by our workmanship guarantee." },
    { icon: <Zap size={22} />, title: "Same-Day Availability", desc: "For urgent (non-emergency) work, we frequently have same-day or next-day availability." },
    { icon: <CheckCircle size={22} />, title: "No Hidden Costs", desc: "Our written quotes are fixed-price where possible — what we quote is what you pay." },
    { icon: <Award size={22} />, title: "Experienced Engineers", desc: "Our plumbers have a minimum of 5 years hands-on experience with domestic plumbing systems." },
  ];
  return (
    <section className="py-12 px-4 bg-secondary">
      <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-5">
        {cards.map((c) => (
          <div key={c.title} className="flex gap-4 bg-card border border-border rounded-xl p-5">
            <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center text-accent shrink-0">{c.icon}</div>
            <div>
              <h3 className="font-bold text-foreground mb-1">{c.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{c.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ─── BLOCK: gallery ───────────────────────────────────────────────────────────

function GalleryBlock() {
  const [selected, setSelected] = useState<null | typeof GALLERY_IMAGES[0]>(null);
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <SectionLabel>Photo Gallery</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>Our Work in Pictures</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {GALLERY_IMAGES.map((img) => (
            <button key={img.url} onClick={() => setSelected(img)} className="group relative rounded-xl overflow-hidden bg-muted h-56">
              <img src={img.url} alt={img.alt} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-primary/0 group-hover:bg-primary/40 transition-colors flex items-center justify-center">
                <Camera size={28} className="text-white opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </button>
          ))}
        </div>
        {selected && (
          <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={() => setSelected(null)}>
            <div className="max-w-3xl w-full rounded-2xl overflow-hidden relative" onClick={(e) => e.stopPropagation()}>
              <img src={selected.url} alt={selected.alt} className="w-full max-h-[80vh] object-contain bg-black" />
              <p className="bg-black text-white text-center text-sm py-2 px-4">{selected.alt}</p>
              <button onClick={() => setSelected(null)} className="absolute top-3 right-3 bg-white/10 text-white rounded-full p-1.5 hover:bg-white/20 transition-colors">
                <X size={20} />
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

// ─── BLOCK: blog_index ────────────────────────────────────────────────────────

function BlogIndexBlock({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <SectionLabel>Latest Articles</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>Plumbing Tips & Advice</h2>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto">Practical advice from our engineers to help you maintain your home plumbing and spot problems early.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {BLOG_POSTS.map((post) => (
            <button key={post.slug} onClick={() => navigate("blog-post")} className="group text-left bg-card border border-border rounded-xl p-6 hover:border-accent hover:shadow-md transition-all">
              <div className="flex gap-2 mb-3">
                <span className="text-xs bg-accent/10 text-accent font-semibold px-2 py-0.5 rounded-full">{post.category}</span>
                <span className="text-xs text-muted-foreground">{post.readTime}</span>
              </div>
              <h3 className="font-bold text-foreground text-lg mb-2 group-hover:text-accent transition-colors">{post.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-4">{post.excerpt}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{post.date}</span>
                <span className="text-accent text-sm font-semibold flex items-center gap-1">Read more <ChevronRight size={14} /></span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: blog_post ─────────────────────────────────────────────────────────

function BlogPostBlock() {
  const post = BLOG_POSTS[0];
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <div className="flex gap-2 mb-3">
            <span className="text-xs bg-accent/10 text-accent font-semibold px-2 py-0.5 rounded-full">{post.category}</span>
            <span className="text-xs text-muted-foreground">{post.readTime} · {post.date}</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-foreground mb-4" style={{ fontFamily: "var(--font-display)" }}>{post.title}</h1>
          <p className="text-muted-foreground text-lg">{post.excerpt}</p>
        </div>
        <img src={GALLERY_IMAGES[0].url} alt={GALLERY_IMAGES[0].alt} className="w-full h-64 object-cover rounded-2xl mb-8" />
        <div className="space-y-4 text-muted-foreground leading-relaxed text-base">
          <p>A dripping tap is one of the most common plumbing problems in UK homes — and one of the most wasteful. A slow drip can lose over 5,500 litres of water a year, adding roughly £15–£30 to your annual water bill depending on your tariff. That might not sound like much, but multiplied across thousands of properties it represents enormous waste.</p>
          <h2 className="text-xl font-bold text-foreground mt-6">What Causes a Dripping Tap?</h2>
          <p>The most common culprit is a worn rubber washer inside the tap's headwork. Every time you turn the tap on and off, the washer presses against a metal seat to form a watertight seal. Over time, that washer degrades and fails to seat properly, allowing water to seep through even when the tap is "off".</p>
          <p>In ceramic disc taps, the discs themselves can chip or crack — particularly if the water in your area is hard (as it is across much of Berkshire). Hard water deposits can build up on the ceramic faces and prevent a proper seal.</p>
          <h2 className="text-xl font-bold text-foreground mt-6">Can You Fix It Yourself?</h2>
          <p>Replacing a washer in an older compression tap is a straightforward DIY task if you're comfortable turning off the water supply (look for the isolator valve under the sink). You'll need a spanner, a flat-head screwdriver, and a replacement washer from any DIY shop — typically under £1.</p>
          <p>Ceramic cartridge replacement is slightly more involved and varies by tap model. If you're unsure, it's quicker and often cheaper in the long run to call a plumber who will have the right cartridge in the van.</p>
          <h2 className="text-xl font-bold text-foreground mt-6">When to Call a Plumber</h2>
          <p>If you've replaced the washer and the drip persists, the tap seat itself may be damaged and need reseating or the entire headwork replacing. We'd recommend calling us at this point rather than risking further damage.</p>
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: online_booking ────────────────────────────────────────────────────

function OnlineBookingBlock() {
  const [step, setStep] = useState(1);
  const [sel, setSel] = useState({ service: "", date: "", time: "", name: "", phone: "" });
  const times = ["8:00 AM", "10:00 AM", "12:00 PM", "2:00 PM", "4:00 PM", "6:00 PM"];

  const today = new Date();
  const days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() + i + 1);
    return d;
  });

  const formatDate = (d: Date) => d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });

  if (step === 4) {
    return (
      <section className="py-16 px-4 bg-secondary">
        <div className="max-w-2xl mx-auto text-center">
          <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} className="text-accent" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Booking Request Sent!</h2>
          <p className="text-muted-foreground mb-1">We've received your request for <strong className="text-foreground">{sel.service}</strong>.</p>
          <p className="text-muted-foreground">We'll call you on <strong className="text-foreground">{sel.phone}</strong> to confirm the appointment for <strong className="text-foreground">{sel.date} at {sel.time}</strong>.</p>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 px-4 bg-secondary">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-10">
          <SectionLabel>Online Booking</SectionLabel>
          <h2 className="text-3xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>Book an Appointment</h2>
          <p className="mt-2 text-muted-foreground text-sm">Choose your service, date and time — we'll confirm by phone within the hour.</p>
          {/* Progress */}
          <div className="flex items-center justify-center gap-2 mt-6">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-2">
                <div className={`w-7 h-7 rounded-full text-xs font-bold flex items-center justify-center ${s <= step ? "bg-primary text-white" : "bg-border text-muted-foreground"}`}>{s}</div>
                {s < 3 && <div className={`h-0.5 w-8 ${s < step ? "bg-primary" : "bg-border"}`} />}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 md:p-8">
          {step === 1 && (
            <div>
              <h3 className="font-bold text-foreground mb-4">1. Choose a Service</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SERVICES_DATA.map((s) => (
                  <button
                    key={s.slug}
                    onClick={() => { setSel({ ...sel, service: s.title }); setStep(2); }}
                    className={`text-left p-4 rounded-xl border-2 transition-all ${sel.service === s.title ? "border-accent bg-accent/5" : "border-border hover:border-accent/50"}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-accent">{s.icon}</div>
                      <span className="font-semibold text-sm text-foreground">{s.title}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 2 && (
            <div>
              <button onClick={() => setStep(1)} className="flex items-center gap-1 text-muted-foreground text-sm mb-4 hover:text-accent transition-colors">
                <ChevronLeft size={16} /> Back
              </button>
              <h3 className="font-bold text-foreground mb-4">2. Choose a Date & Time</h3>
              <div className="mb-4">
                <p className="text-sm font-semibold text-foreground mb-2">Select Date</p>
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {days.map((d) => (
                    <button
                      key={d.toISOString()}
                      onClick={() => setSel({ ...sel, date: formatDate(d) })}
                      className={`shrink-0 px-3 py-2 rounded-lg border text-xs font-semibold transition-all ${sel.date === formatDate(d) ? "bg-primary text-white border-primary" : "bg-background border-border text-foreground hover:border-accent"}`}
                    >
                      {formatDate(d)}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground mb-2">Select Time</p>
                <div className="grid grid-cols-3 gap-2">
                  {times.map((t) => (
                    <button
                      key={t}
                      onClick={() => setSel({ ...sel, time: t })}
                      className={`py-2 rounded-lg border text-sm font-semibold transition-all ${sel.time === t ? "bg-primary text-white border-primary" : "bg-background border-border text-foreground hover:border-accent"}`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <button
                onClick={() => { if (sel.date && sel.time) setStep(3); }}
                disabled={!sel.date || !sel.time}
                className="mt-6 w-full bg-primary text-primary-foreground font-bold py-3 rounded-lg disabled:opacity-40 hover:bg-primary/90 transition-colors"
              >
                Continue
              </button>
            </div>
          )}

          {step === 3 && (
            <div>
              <button onClick={() => setStep(2)} className="flex items-center gap-1 text-muted-foreground text-sm mb-4 hover:text-accent transition-colors">
                <ChevronLeft size={16} /> Back
              </button>
              <h3 className="font-bold text-foreground mb-4">3. Your Details</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-1.5">Full Name *</label>
                  <input required type="text" placeholder="John Smith" value={sel.name} onChange={(e) => setSel({ ...sel, name: e.target.value })}
                    className="w-full bg-input-background border border-border rounded-lg px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-accent/50" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-1.5">Phone Number *</label>
                  <input required type="tel" placeholder="07700 900 000" value={sel.phone} onChange={(e) => setSel({ ...sel, phone: e.target.value })}
                    className="w-full bg-input-background border border-border rounded-lg px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-accent/50" />
                </div>
                <div className="bg-secondary rounded-xl p-4 text-sm space-y-1">
                  <p><span className="font-semibold text-foreground">Service:</span> <span className="text-muted-foreground">{sel.service}</span></p>
                  <p><span className="font-semibold text-foreground">Date:</span> <span className="text-muted-foreground">{sel.date}</span></p>
                  <p><span className="font-semibold text-foreground">Time:</span> <span className="text-muted-foreground">{sel.time}</span></p>
                </div>
                <button
                  onClick={() => { if (sel.name && sel.phone) setStep(4); }}
                  disabled={!sel.name || !sel.phone}
                  className="w-full bg-primary text-primary-foreground font-bold py-3 rounded-lg disabled:opacity-40 hover:bg-primary/90 transition-colors"
                >
                  Confirm Booking Request
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: accreditations ────────────────────────────────────────────────────

function AccreditationsBlock() {
  const items = ["WIAPS Registered", "Trading Standards Approved", "Which? Trusted Trader", "Checkatrade Verified", "Trustpilot 4.9★"];
  return (
    <section className="py-10 px-4 bg-muted border-y border-border">
      <div className="max-w-5xl mx-auto">
        <p className="text-center text-xs font-semibold text-muted-foreground tracking-widest uppercase mb-5">Accreditations & Memberships</p>
        <div className="flex flex-wrap justify-center gap-4">
          {items.map((item) => (
            <div key={item} className="flex items-center gap-2 bg-card border border-border rounded-full px-4 py-2 text-sm font-semibold text-foreground">
              <Award size={16} className="text-accent" /> {item}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: brands ────────────────────────────────────────────────────────────

function BrandsBlock() {
  const brands = ["Grohe", "Hansgrohe", "Roca", "Ideal Standard", "Bristan", "Mira", "Triton", "Crosswater"];
  return (
    <section className="py-10 px-4 bg-background border-b border-border">
      <div className="max-w-5xl mx-auto">
        <p className="text-center text-xs font-semibold text-muted-foreground tracking-widest uppercase mb-5">Brands We Work With</p>
        <div className="flex flex-wrap justify-center gap-3">
          {brands.map((b) => (
            <div key={b} className="bg-secondary border border-border rounded-lg px-4 py-2 text-sm font-semibold text-foreground">{b}</div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: amazon_affiliates ─────────────────────────────────────────────────

function AmazonAffiliatesBlock() {
  const products = [
    { title: "PTFE Thread Seal Tape (Pack of 5)", price: "£4.99", badge: "Bestseller" },
    { title: "Plumbers Mait Non-Setting Jointing Compound", price: "£8.50", badge: "Recommended" },
    { title: "Silicone Grease for Tap Washers", price: "£6.99", badge: "Value Pick" },
    { title: "WD-40 Specialist Silicone Lubricant 400ml", price: "£7.49", badge: "Popular" },
  ];
  return (
    <section className="py-12 px-4 bg-secondary border-b border-border">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <SectionLabel>Recommended Products</SectionLabel>
          <h2 className="text-2xl font-extrabold text-foreground" style={{ fontFamily: "var(--font-display)" }}>Plumbing Supplies We Trust</h2>
          <p className="text-muted-foreground text-sm mt-2">Affiliate links — we may earn a small commission if you purchase.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {products.map((p) => (
            <div key={p.title} className="bg-card border border-border rounded-xl p-5 flex flex-col gap-3">
              <div className="h-20 bg-muted rounded-lg flex items-center justify-center">
                <Wrench size={32} className="text-muted-foreground" />
              </div>
              <span className="text-xs bg-yellow-100 text-yellow-700 font-semibold px-2 py-0.5 rounded-full w-fit">{p.badge}</span>
              <p className="font-semibold text-foreground text-sm leading-snug">{p.title}</p>
              <div className="mt-auto flex items-center justify-between">
                <span className="font-bold text-foreground">{p.price}</span>
                <a href="#" className="text-accent text-xs font-semibold flex items-center gap-1 hover:underline">Amazon <ExternalLink size={11} /></a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: legal_content ─────────────────────────────────────────────────────

function LegalContentBlock() {
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-3xl mx-auto space-y-8 text-sm text-muted-foreground leading-relaxed">
        <div>
          <h2 className="text-xl font-bold text-foreground mb-3">Privacy Policy</h2>
          <p>Last updated: 1 June 2025. {COMPANY} (&ldquo;we&rdquo;, &ldquo;our&rdquo;) is committed to protecting your personal data in accordance with UK GDPR and the Data Protection Act 2018.</p>
          <p className="mt-3">We collect your name, telephone number and email address when you submit an enquiry via our website or telephone us. This data is used solely to respond to your enquiry and fulfil any plumbing services you request.</p>
          <p className="mt-3">We do not sell, share or transfer your personal data to third parties except where required by law or where necessary to fulfil a service (e.g. passing your address to an engineer attending your property).</p>
          <p className="mt-3">You have the right to request access to, correction of, or deletion of your personal data at any time by contacting us at <a href="mailto:hello@localplumbingpro.co.uk" className="text-accent hover:underline">hello@localplumbingpro.co.uk</a>.</p>
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground mb-3">Terms & Conditions</h2>
          <p>These terms govern your use of this website and any services booked through it. By submitting an enquiry or booking form, you agree to these terms.</p>
          <p className="mt-3"><strong className="text-foreground">Quotations:</strong> Written quotes are valid for 30 days. Verbal quotes are indicative and subject to a site survey. We reserve the right to revise a quote if the scope of work differs materially from the original description.</p>
          <p className="mt-3"><strong className="text-foreground">Payment:</strong> Payment is due on completion of work unless otherwise agreed in writing. We accept cash and bank transfer. We do not accept card payments.</p>
          <p className="mt-3"><strong className="text-foreground">Guarantee:</strong> Workmanship is guaranteed for 12 months from the date of completion. This guarantee covers defects in our work only and does not cover damage caused by subsequent interference with our work or pre-existing conditions we were not made aware of.</p>
          <p className="mt-3"><strong className="text-foreground">Cancellation:</strong> Please give at least 24 hours&apos; notice if you need to cancel or rearrange an appointment. Late cancellations (under 4 hours) may incur a charge equivalent to 1 hour of our standard labour rate.</p>
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground mb-3">Cookie Policy</h2>
          <p>This website uses only strictly necessary cookies required for the site to function. We do not use tracking, analytics or advertising cookies. No cookie consent banner is required.</p>
        </div>
      </div>
    </section>
  );
}

// ─── BLOCK: spacer ────────────────────────────────────────────────────────────

function SpacerBlock({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const map = { sm: "h-8", md: "h-16", lg: "h-24" };
  return <div className={map[size]} />;
}

// ─── Pages ────────────────────────────────────────────────────────────────────

function HomePage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock
        title="Reliable Local Plumbing Services"
        subtitle="Honest, fast and fully insured plumbers serving Reading and the surrounding area. Free quotes, 12-month guarantee."
        navigate={navigate}
        showTrust
        bgImage="https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=1400&h=700&fit=crop&auto=format"
      />
      {/* features_bar */}
      <FeaturesBarBlock />
      {/* services */}
      <ServicesBlock navigate={navigate} />
      {/* why_choose_us */}
      <WhyChooseUsBlock />
      {/* process */}
      <ProcessBlock />
      {/* areas */}
      <AreasBlock navigate={navigate} />
      {/* testimonials */}
      <TestimonialsBlock />
      {/* project_showcase */}
      <ProjectShowcaseBlock navigate={navigate} />
      {/* faq */}
      <FaqBlock />
      {/* cta */}
      <CtaBlock navigate={navigate} />
      {/* contact_form */}
      <ContactFormBlock />
    </>
  );
}

function ServicesPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Our Plumbing Services" subtitle="From dripping taps to full re-pipes — expert, reliable plumbing for all domestic needs." navigate={navigate} />
      {/* text */}
      <TextBlock title="Comprehensive Domestic Plumbing">
        <p>We cover the full range of domestic plumbing work across Reading and the surrounding area. Whether you need a washer replaced on a leaky tap or a complete bathroom re-pipe, our experienced engineers deliver the same high standard of work every time.</p>
        <p>All work is quoted upfront in writing, completed to a professional standard and backed by our 12-month workmanship guarantee.</p>
      </TextBlock>
      {/* services */}
      <ServicesBlock navigate={navigate} />
      {/* feature_cards */}
      <FeatureCardsBlock />
      {/* accreditations */}
      <AccreditationsBlock />
      {/* brands */}
      <BrandsBlock />
      {/* cta */}
      <CtaBlock navigate={navigate} />
      {/* faq */}
      <FaqBlock />
      {/* contact_form */}
      <ContactFormBlock />
    </>
  );
}

function ServiceDetailPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Leak Detection & Repair" subtitle="Fast, accurate leak finding and repair — protecting your home from water damage." navigate={navigate} />
      {/* text */}
      <TextBlock title="About Our Leak Repair Service">
        <p>Water leaks are one of the most damaging plumbing problems a homeowner can face. Left undetected, even a slow drip inside a wall or floor can cause structural damage, mould growth and expensive repair bills.</p>
        <p>Our engineers use pressure testing and acoustic detection methods to locate concealed leaks with minimal disruption to your property. Once found, we carry out a durable repair — not a temporary patch — and test thoroughly before leaving.</p>
      </TextBlock>
      {/* image */}
      <ImageBlock src="https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=900&h=500&fit=crop&auto=format" alt="Engineer tracing a pipe leak under a kitchen sink" caption="Pressure testing and visual inspection before any invasive work" />
      {/* features_bar */}
      <FeaturesBarBlock />
      {/* process */}
      <ProcessBlock />
      {/* why_choose_us */}
      <WhyChooseUsBlock />
      {/* testimonials */}
      <TestimonialsBlock />
      {/* faq */}
      <FaqBlock items={[
        { q: "How do you find a hidden leak?", a: "We use a combination of pressure testing, acoustic listening equipment and thermal observation to trace concealed leaks without unnecessary excavation." },
        { q: "Will you need to open up my walls?", a: "We always try to avoid unnecessary damage. In many cases we can access the pipe without significant disruption, but we'll always explain what's required before starting work." },
        ...FAQ_DATA.slice(0, 3),
      ]} />
      {/* cta */}
      <CtaBlock navigate={navigate} />
      {/* contact_form */}
      <ContactFormBlock />
    </>
  );
}

function EmergencyPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="24/7 Emergency Plumbing" subtitle="Burst pipes, severe leaks, flooding — we answer our phones around the clock and aim to reach you within 2 hours." navigate={navigate} emergencyMode />
      {/* features_bar */}
      <FeaturesBarBlock />
      {/* text */}
      <TextBlock title="What to Do in a Plumbing Emergency" bg="bg-secondary">
        <p><strong>Step 1 — Turn off your water:</strong> Locate your main stop tap (usually under the kitchen sink or where the supply enters the property) and turn it clockwise to shut off the supply.</p>
        <p><strong>Step 2 — Switch off the immersion or any water heaters:</strong> This prevents dry-firing if the tank drains.</p>
        <p><strong>Step 3 — Call us immediately:</strong> Ring <a href={PHONE_HREF} className="text-accent font-semibold">{PHONE}</a> — we answer 24 hours a day, 7 days a week.</p>
        <p><strong>Step 4 — Contain any water:</strong> Use towels and buckets to limit spread while you wait for us to arrive.</p>
      </TextBlock>
      {/* services */}
      <ServicesBlock navigate={navigate} />
      {/* process */}
      <ProcessBlock />
      {/* faq */}
      <FaqBlock items={[
        { q: "Do you really answer calls at 2am?", a: "Yes. Our emergency line is staffed around the clock, every day of the year including bank holidays. You'll speak to a real person, not a machine." },
        { q: "How much does an emergency call-out cost?", a: "We'll give you a clear call-out fee before we attend. Emergency rates are higher than standard daytime rates, but we're always transparent before any charges apply." },
        ...FAQ_DATA.slice(0, 3),
      ]} />
      {/* cta */}
      <CtaBlock navigate={navigate} />
      {/* contact */}
      <ContactBlock />
    </>
  );
}

function AreasPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Areas We Cover" subtitle="Local plumbers serving Reading, Berkshire and the surrounding towns and villages." navigate={navigate} />
      {/* text */}
      <TextBlock title="Our Service Area">
        <p>We're based in Reading and cover all areas within approximately 20 miles of the town centre. That includes the major towns and hundreds of villages across south Berkshire, parts of Oxfordshire and north Hampshire.</p>
        <p>If you're unsure whether we cover your area, just give us a ring — we'll let you know straight away.</p>
      </TextBlock>
      {/* areas */}
      <AreasBlock navigate={navigate} />
      {/* image */}
      <ImageBlock src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=900&h=450&fit=crop&auto=format" alt="Plumber in a van ready to attend a local call" caption="Our engineers operate across the full coverage area with same-day availability" />
      {/* cta */}
      <CtaBlock navigate={navigate} />
      {/* faq */}
      <FaqBlock items={[
        { q: "Do you cover rural properties?", a: "Yes — we cover properties in rural villages as well as urban areas. Farms, converted barns and rural cottages are all on our patch." },
        { q: "Is there a travel surcharge?", a: "For locations within our core coverage area (roughly 15 miles of Reading) there's no travel charge. Properties beyond this may incur a small mileage supplement — we'll always advise you upfront." },
        ...FAQ_DATA.slice(3),
      ]} />
      {/* contact_form */}
      <ContactFormBlock />
    </>
  );
}

function ReviewsPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Customer Reviews" subtitle="Don't just take our word for it — see what our customers say about our work." navigate={navigate} />
      {/* testimonials */}
      <TestimonialsBlock />
      {/* project_showcase */}
      <ProjectShowcaseBlock navigate={navigate} />
      {/* cta */}
      <CtaBlock navigate={navigate} />
      {/* contact_form */}
      <ContactFormBlock />
    </>
  );
}

function GalleryPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Work Gallery" subtitle="A selection of recent projects completed by our engineers." navigate={navigate} />
      {/* gallery */}
      <GalleryBlock />
      {/* project_showcase */}
      <ProjectShowcaseBlock navigate={navigate} />
      {/* cta */}
      <CtaBlock navigate={navigate} />
      {/* contact_form */}
      <ContactFormBlock />
    </>
  );
}

function BlogIndexPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Plumbing Tips & Advice" subtitle="Practical guides from our engineers to help you care for your home's plumbing." navigate={navigate} />
      {/* blog_index */}
      <BlogIndexBlock navigate={navigate} />
      {/* cta */}
      <CtaBlock navigate={navigate} />
    </>
  );
}

function BlogPostPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="How to Stop a Dripping Tap" subtitle="A dripping tap can waste thousands of litres a year. Here's how to fix it." navigate={navigate} />
      {/* blog_post */}
      <BlogPostBlock />
      {/* cta */}
      <CtaBlock navigate={navigate} />
      {/* faq */}
      <FaqBlock items={FAQ_DATA.slice(0, 4)} />
    </>
  );
}

function BookingPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Book an Appointment" subtitle="Choose your service and preferred time — we'll confirm by phone." navigate={navigate} />
      {/* online_booking */}
      <OnlineBookingBlock />
      {/* text */}
      <TextBlock title="Need an Emergency Appointment?">
        <p>Our online booking form is for planned, non-urgent work. If you have a plumbing emergency — burst pipe, severe leak or flooding — please call us directly on <a href={PHONE_HREF} className="text-accent font-semibold">{PHONE}</a>. We're available 24 hours a day, 7 days a week.</p>
      </TextBlock>
      {/* faq */}
      <FaqBlock items={FAQ_DATA.slice(0, 4)} />
      {/* contact */}
      <ContactBlock />
    </>
  );
}

function ContactPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Contact Us" subtitle="We're here to help — call, email or fill in the form below." navigate={navigate} />
      {/* contact */}
      <ContactBlock />
      {/* contact_form */}
      <ContactFormBlock />
      {/* areas */}
      <AreasBlock navigate={navigate} />
      {/* faq */}
      <FaqBlock />
    </>
  );
}

function LegalPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Legal & Policies" subtitle="Our privacy policy, terms and conditions, and cookie policy." navigate={navigate} />
      {/* legal_content */}
      <LegalContentBlock />
    </>
  );
}

function NotFoundPage({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <>
      {/* hero */}
      <HeroBlock title="Page Not Found" subtitle="Sorry, we couldn't find what you were looking for." navigate={navigate} />
      {/* text */}
      <TextBlock>
        <p>The page you requested doesn't exist or may have been moved. Use the navigation above to find what you're looking for, or go back to our homepage.</p>
      </TextBlock>
      {/* cta */}
      <section className="py-12 px-4 bg-secondary">
        <div className="max-w-xl mx-auto text-center flex flex-col sm:flex-row gap-4 justify-center">
          <button onClick={() => navigate("home")} className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold px-6 py-3 rounded-lg hover:bg-primary/90 transition-all">
            <Home size={18} /> Back to Homepage
          </button>
          <button onClick={() => navigate("contact")} className="inline-flex items-center justify-center gap-2 bg-accent text-white font-bold px-6 py-3 rounded-lg hover:brightness-110 transition-all">
            <Phone size={18} /> Contact Us
          </button>
        </div>
      </section>
    </>
  );
}

// ─── Page Tab Nav (demo) ──────────────────────────────────────────────────────

function PageNav({ current, navigate }: { current: Page; navigate: (p: Page) => void }) {
  const pages: { label: string; page: Page }[] = [
    { label: "Home", page: "home" },
    { label: "Services", page: "services" },
    { label: "Service Detail", page: "service-detail" },
    { label: "Emergency", page: "emergency" },
    { label: "Areas", page: "areas" },
    { label: "Reviews", page: "reviews" },
    { label: "Gallery", page: "gallery" },
    { label: "Blog Index", page: "blog-index" },
    { label: "Blog Post", page: "blog-post" },
    { label: "Booking", page: "booking" },
    { label: "Contact", page: "contact" },
    { label: "Legal", page: "legal" },
    { label: "404", page: "404" },
  ];
  return (
    <div className="bg-foreground text-primary-foreground py-2 px-4 overflow-x-auto">
      <div className="flex gap-1 min-w-max">
        <span className="text-white/40 text-xs flex items-center mr-2 shrink-0"><FileText size={13} className="mr-1" /> Pages:</span>
        {pages.map((p) => (
          <button
            key={p.page}
            onClick={() => navigate(p.page)}
            className={`text-xs px-3 py-1 rounded transition-colors whitespace-nowrap ${current === p.page ? "bg-accent text-white font-semibold" : "text-white/60 hover:text-white hover:bg-white/10"}`}
          >
            {p.label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPage] = useState<Page>("home");

  const navigate = (p: Page) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const renderPage = () => {
    switch (page) {
      case "home": return <HomePage navigate={navigate} />;
      case "services": return <ServicesPage navigate={navigate} />;
      case "service-detail": return <ServiceDetailPage navigate={navigate} />;
      case "emergency": return <EmergencyPage navigate={navigate} />;
      case "areas": return <AreasPage navigate={navigate} />;
      case "reviews": return <ReviewsPage navigate={navigate} />;
      case "gallery": return <GalleryPage navigate={navigate} />;
      case "blog-index": return <BlogIndexPage navigate={navigate} />;
      case "blog-post": return <BlogPostPage navigate={navigate} />;
      case "booking": return <BookingPage navigate={navigate} />;
      case "contact": return <ContactPage navigate={navigate} />;
      case "legal": return <LegalPage navigate={navigate} />;
      case "404": return <NotFoundPage navigate={navigate} />;
      default: return <HomePage navigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col" style={{ fontFamily: "var(--font-sans)" }}>
      {/* Demo page switcher bar */}
      <PageNav current={page} navigate={navigate} />
      <SiteHeader currentPage={page} navigate={navigate} />
      <main className="flex-1 pb-16 md:pb-0">
        {renderPage()}
      </main>
      <SiteFooter navigate={navigate} />
      {/* sticky_mobile_cta */}
      <StickyMobileCta navigate={navigate} />
    </div>
  );
}
